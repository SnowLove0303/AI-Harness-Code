---- MODULE ShadowSub ----
CONSTANT c
====
